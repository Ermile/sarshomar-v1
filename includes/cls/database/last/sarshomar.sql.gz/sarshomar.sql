-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 18, 2017 at 12:17 PM
-- Server version: 5.7.19-0ubuntu0.16.04.1
-- PHP Version: 7.1.6-1~ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `sarshomar`
--

-- --------------------------------------------------------

--
-- Table structure for table `answerdetails`
--

CREATE TABLE `answerdetails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `answer_id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `port` enum('site','telegram','sms','api') NOT NULL DEFAULT 'site',
  `validstatus` enum('valid','invalid') DEFAULT NULL,
  `subport` varchar(100) DEFAULT NULL,
  `opt` tinyint(3) UNSIGNED DEFAULT NULL,
  `answertype` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `txt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `profile` bigint(20) UNSIGNED DEFAULT NULL,
  `ask` bit(1) DEFAULT NULL,
  `visitor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('enable','disable','deleted') DEFAULT 'enable',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_affected` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `answers`
--

CREATE TABLE `answers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `lastopt` tinyint(3) DEFAULT NULL,
  `ask` bit(1) DEFAULT NULL,
  `countupdate` int(10) UNSIGNED DEFAULT NULL,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `apilogs`
--

CREATE TABLE `apilogs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `url` varchar(760) CHARACTER SET utf8mb4 DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `responseheader` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `requestheader` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `request` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `response` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `pagestatus` varchar(50) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `debug` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `apikey` varchar(200) DEFAULT NULL,
  `apikeyuserid` int(10) UNSIGNED DEFAULT NULL,
  `token` varchar(200) DEFAULT NULL,
  `meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `visit_id` bigint(20) UNSIGNED DEFAULT NULL,
  `clientip` int(50) UNSIGNED DEFAULT NULL,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `commentdetails`
--

CREATE TABLE `commentdetails` (
  `user_id` int(10) UNSIGNED NOT NULL,
  `comment_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('minus','plus') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `comment_author` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `comment_email` varchar(100) DEFAULT NULL,
  `comment_url` varchar(100) DEFAULT NULL,
  `comment_content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `comment_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `comment_status` enum('approved','unapproved','spam','deleted') NOT NULL DEFAULT 'unapproved',
  `comment_parent` smallint(5) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `comment_minus` int(10) UNSIGNED DEFAULT NULL,
  `comment_plus` int(10) UNSIGNED DEFAULT NULL,
  `comment_type` enum('comment','rate') DEFAULT NULL,
  `visitor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `exchangerates`
--

CREATE TABLE `exchangerates` (
  `id` int(10) UNSIGNED NOT NULL,
  `from` smallint(5) UNSIGNED NOT NULL,
  `to` smallint(5) UNSIGNED NOT NULL,
  `rate` double NOT NULL,
  `roundtype` enum('up','down','round') DEFAULT NULL,
  `round` double DEFAULT NULL,
  `wagestatic` double DEFAULT NULL,
  `wage` double DEFAULT NULL,
  `status` enum('enable','disable','deleted','expired','awaiting','filtered','blocked','spam') NOT NULL,
  `desc` text,
  `meta` text,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enddate` datetime DEFAULT NULL,
  `datemodified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `filters`
--

CREATE TABLE `filters` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `count` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `gender` enum('male','female') DEFAULT NULL,
  `marrital` enum('single','married') DEFAULT NULL,
  `internetusage` enum('low','mid','high') DEFAULT NULL,
  `graduation` enum('illiterate','undergraduate','graduate') DEFAULT NULL,
  `degree` enum('under diploma','diploma','2 year college','bachelor','master','phd','other') DEFAULT NULL,
  `course` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `age` smallint(3) DEFAULT NULL,
  `agemin` smallint(3) DEFAULT NULL,
  `agemax` smallint(3) DEFAULT NULL,
  `range` enum('-13','14-17','18-24','25-30','31-44','45-59','60+') DEFAULT NULL,
  `country` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `province` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `city` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `employmentstatus` enum('employee','unemployed','retired','unemployee') DEFAULT NULL,
  `housestatus` enum('owner','tenant','homeless') DEFAULT NULL,
  `religion` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `language` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `industry` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `logitems`
--

CREATE TABLE `logitems` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `logitem_type` varchar(100) DEFAULT NULL,
  `logitem_caller` varchar(100) NOT NULL,
  `logitem_title` varchar(100) NOT NULL,
  `logitem_desc` varchar(100) DEFAULT NULL,
  `logitem_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `count` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `logitem_priority` enum('critical','high','medium','low') NOT NULL DEFAULT 'medium',
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `logs`
--

CREATE TABLE `logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `logitem_id` smallint(5) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `log_data` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `log_desc` varchar(250) DEFAULT NULL,
  `log_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `log_status` enum('enable','disable','expire','deliver') DEFAULT NULL,
  `log_createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_idsender` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `notification_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `notification_content` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `notification_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `notification_url` varchar(100) DEFAULT NULL,
  `notification_status` enum('read','unread','expire') NOT NULL DEFAULT 'unread',
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `options`
--

CREATE TABLE `options` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `option_cat` varchar(100) NOT NULL,
  `option_key` varchar(100) NOT NULL,
  `option_value` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `option_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `option_status` enum('enable','disable','expire') NOT NULL DEFAULT 'enable',
  `option_createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `polldetails`
--

CREATE TABLE `polldetails` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `port` enum('site','telegram','sms','api') NOT NULL DEFAULT 'site',
  `validstatus` enum('valid','invalid') DEFAULT NULL,
  `subport` varchar(100) DEFAULT NULL,
  `opt` tinyint(3) UNSIGNED DEFAULT NULL,
  `answertype` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `type` varchar(50) DEFAULT NULL,
  `txt` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `profile` bigint(20) UNSIGNED DEFAULT NULL,
  `visitor_id` bigint(20) UNSIGNED DEFAULT NULL,
  `status` enum('enable','disable') DEFAULT 'enable',
  `insertdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pollopts`
--

CREATE TABLE `pollopts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `key` smallint(3) UNSIGNED DEFAULT NULL,
  `type` enum('select','emoji','descriptive','upload','range','notification','like','star') DEFAULT NULL,
  `subtype` varchar(100) DEFAULT NULL,
  `true` bit(1) DEFAULT b'0',
  `groupscore` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `score` smallint(5) DEFAULT NULL,
  `attachment_id` bigint(20) UNSIGNED DEFAULT NULL,
  `attachmenttype` enum('image','audio','video','pdf','other') DEFAULT NULL,
  `desc` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `meta` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `status` enum('enable','disable','expired','awaiting','filtered','blocked','spam') NOT NULL DEFAULT 'enable',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `pollstats`
--

CREATE TABLE `pollstats` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `type` enum('valid','invalid') NOT NULL DEFAULT 'invalid',
  `port` enum('site','telegram','sms','api') NOT NULL DEFAULT 'site',
  `subport` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `total` int(10) UNSIGNED DEFAULT NULL,
  `result` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `gender` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `marrital` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `graduation` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `degree` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `employmentstatus` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `housestatus` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `internetusage` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `range` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `age` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `country` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `province` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `city` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `language` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `religion` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `course` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `industry` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `polltrees`
--

CREATE TABLE `polltrees` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `parent` bigint(20) UNSIGNED NOT NULL,
  `opt` smallint(3) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `posts`
--

CREATE TABLE `posts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_language` char(2) DEFAULT NULL,
  `post_title` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `post_slug` varchar(255) CHARACTER SET utf8mb4 NOT NULL,
  `post_url` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `post_content` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `post_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `post_type` varchar(100) NOT NULL DEFAULT 'post',
  `post_comment` enum('open','closed') DEFAULT NULL,
  `post_count` smallint(5) UNSIGNED DEFAULT NULL,
  `post_order` int(10) UNSIGNED DEFAULT NULL,
  `post_status` enum('stop','pause','trash','publish','draft','enable','disable','deleted','schedule','expired','awaiting','filtered','blocked','spam','violence','pornography','other') NOT NULL DEFAULT 'draft',
  `post_parent` bigint(20) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_survey` bigint(20) UNSIGNED DEFAULT NULL,
  `post_sarshomar` bit(1) DEFAULT NULL,
  `post_privacy` enum('public','private') DEFAULT NULL,
  `post_rank` bigint(20) DEFAULT NULL,
  `post_createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `post_publishdate` datetime DEFAULT NULL,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `post_member` int(10) UNSIGNED DEFAULT '0',
  `post_asked` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `post_hasfilter` bit(1) DEFAULT b'0',
  `post_hasmedia` bit(1) DEFAULT b'0',
  `post_prize` int(10) UNSIGNED DEFAULT NULL,
  `post_prizeunit` smallint(5) UNSIGNED DEFAULT NULL,
  `post_password` varchar(50) DEFAULT NULL,
  `post_brand` varchar(255) DEFAULT NULL,
  `post_brandurl` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `ranks`
--

CREATE TABLE `ranks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED NOT NULL,
  `member` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `public` bit(1) NOT NULL DEFAULT b'0',
  `filter` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `ad` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `money` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `report` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `vote` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `like` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `fav` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skip` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `comment` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `view` bigint(20) UNSIGNED NOT NULL DEFAULT '0',
  `other` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `sarshomar` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `ago` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `admin` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `vip` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `value` bigint(20) NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Triggers `ranks`
--
DELIMITER $$
CREATE TRIGGER `ranks_change_posts_rank_on_update` AFTER UPDATE ON `ranks` FOR EACH ROW BEGIN
	UPDATE posts SET posts.post_rank = NEW.value WHERE posts.id = NEW.post_id LIMIT 1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(64) NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `status` enum('active','terminate','expire','disable','changed','logout') NOT NULL DEFAULT 'active',
  `agent_id` int(10) UNSIGNED DEFAULT NULL,
  `ip` int(10) UNSIGNED DEFAULT NULL,
  `count` int(10) UNSIGNED DEFAULT '1',
  `createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `last_seen` datetime DEFAULT NULL,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `id` int(10) UNSIGNED NOT NULL,
  `term_language` char(2) DEFAULT NULL,
  `term_type` varchar(100) NOT NULL DEFAULT 'tag',
  `term_caller` varchar(100) DEFAULT NULL,
  `term_title` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `term_slug` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `term_url` varchar(100) NOT NULL,
  `term_desc` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `term_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `term_parent` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED DEFAULT NULL,
  `term_status` enum('enable','disable','expired','awaiting','filtered','blocked','spam','violence','pornography','other') NOT NULL DEFAULT 'awaiting',
  `term_count` int(10) UNSIGNED DEFAULT NULL,
  `term_usercount` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `term_createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Triggers `terms`
--
DELIMITER $$
CREATE TRIGGER `terms_set_terms_url_caller_on_insert` BEFORE INSERT ON `terms` FOR EACH ROW BEGIN

IF(NEW.term_parent IS NOT NULL AND NEW.term_parent != '') THEN
	IF(NEW.term_url IS NULL OR NEW.term_url = '') THEN
		SET NEW.term_url = CONCAT_WS('/', (SELECT term_url FROM terms WHERE id = NEW.term_parent LIMIT 1), NEW.term_slug);
	END IF;

	IF(NEW.term_caller IS NULL OR NEW.term_caller = '') THEN
		SET NEW.term_caller = CONCAT_WS(':', (SELECT term_caller FROM terms WHERE id = NEW.term_parent LIMIT 1), NEW.term_slug);
	END IF;
END IF;

IF(NEW.term_parent IS NULL OR NEW.term_parent = '') THEN
	IF(NEW.term_url IS NULL OR NEW.term_url = '') THEN
		SET NEW.term_url    = CONCAT_WS('/', '$', NEW.term_slug);
	END IF;

	IF(NEW.term_caller IS NULL OR NEW.term_caller = '') THEN
		SET NEW.term_caller = NEW.term_slug;
	END IF;
END IF;

IF(NEW.term_type = 'sarshomar_tag') THEN
	IF(NEW.term_url IS NULL OR NEW.term_url = '') THEN
		SET NEW.term_url = CONCAT_WS('/', '$', 'tag', NEW.term_slug);
	END IF;
END IF;

END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `termusages`
--

CREATE TABLE `termusages` (
  `term_id` int(10) UNSIGNED NOT NULL,
  `termusage_id` bigint(20) UNSIGNED NOT NULL,
  `termusage_foreign` enum('posts','products','attachments','files','comments','users','pollopts','profile','filter','cat','tag','user_profile') DEFAULT NULL,
  `termusage_status` enum('enable','disable','expired') NOT NULL DEFAULT 'enable',
  `termusage_order` smallint(5) UNSIGNED DEFAULT NULL,
  `termusage_createdate` datetime DEFAULT CURRENT_TIMESTAMP,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Triggers `termusages`
--
DELIMITER $$
CREATE TRIGGER `termusages_change_terms_count_usercount_on_delete` AFTER DELETE ON `termusages` FOR EACH ROW BEGIN
	IF(OLD.termusage_foreign = 'posts') THEN
		UPDATE IGNORE terms SET terms.term_count = IF(terms.term_count IS NULL OR terms.term_count = '' OR terms.term_count < 1, 0, terms.term_count - 1) WHERE	terms.id = OLD.term_id LIMIT 1;
	END IF;

	IF(OLD.termusage_foreign = 'users') THEN
		UPDATE IGNORE terms SET terms.term_usercount = IF(terms.term_usercount IS NULL OR terms.term_usercount = '' OR terms.term_usercount < 1, 0, terms.term_usercount - 1) WHERE	terms.id = OLD.term_id LIMIT 1;
	END IF;



UPDATE IGNORE
	options
SET
	options.option_meta = IF(options.option_meta IS NULL OR options.option_meta = '' OR options.option_meta < 1, 0, options.option_meta - 1)
WHERE
	options.user_id      IS NULL AND
	options.post_id      IS NULL AND
	options.option_cat   = 'termusages_detail' AND
	options.option_key   = 'usage_count' AND
	options.option_value = OLD.termusage_foreign;



END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `termusages_change_terms_count_usercount_on_insert` AFTER INSERT ON `termusages` FOR EACH ROW BEGIN
	IF(NEW.termusage_foreign = 'posts') THEN
		UPDATE IGNORE terms SET terms.term_count = IF(terms.term_count IS NULL OR terms.term_count = '', 1, terms.term_count + 1) WHERE	terms.id = NEW.term_id LIMIT 1;
	END IF;

	IF(NEW.termusage_foreign = 'users') THEN
		UPDATE IGNORE terms SET terms.term_usercount = IF(terms.term_usercount IS NULL OR terms.term_usercount = '', 1, terms.term_usercount + 1) WHERE	terms.id = NEW.term_id LIMIT 1;
	END IF;



INSERT INTO
	options
SET
	options.user_id      = NULL,
	options.post_id      = NULL,
	options.option_cat   = 'termusages_detail',
	options.option_key   = 'usage_count',
	options.option_value = NEW.termusage_foreign,
	options.option_meta  = 1
ON DUPLICATE KEY UPDATE
	options.option_meta = IF(options.option_meta IS NULL OR options.option_meta = '', 1, options.option_meta + 1);



END
$$
DELIMITER ;
DELIMITER $$
CREATE TRIGGER `termusages_change_terms_count_usercount_on_update` AFTER UPDATE ON `termusages` FOR EACH ROW BEGIN
		IF(NEW.termusage_foreign = 'posts') THEN
				UPDATE IGNORE terms SET terms.term_count = IF(terms.term_count IS NULL OR terms.term_count = '', 1, terms.term_count + 1) WHERE terms.id = NEW.term_id LIMIT 1;
				UPDATE IGNORE terms SET terms.term_count = IF(terms.term_count IS NULL OR terms.term_count = '' OR terms.term_count < 1, 0, terms.term_count - 1) WHERE terms.id = OLD.term_id LIMIT 1;
	END IF;
		IF(NEW.termusage_foreign = 'users') THEN
				UPDATE IGNORE terms SET terms.term_usercount = IF(terms.term_usercount IS NULL OR terms.term_usercount = '', 1, terms.term_usercount + 1) WHERE terms.id = NEW.term_id LIMIT 1;
				UPDATE IGNORE terms SET terms.term_usercount = IF(terms.term_usercount IS NULL OR terms.term_usercount = '' OR terms.term_usercount < 1, 0, terms.term_usercount - 1) WHERE terms.id = OLD.term_id LIMIT 1;
END IF;



INSERT INTO
	options
SET
	options.user_id      = NULL,
	options.post_id      = NULL,
	options.option_cat   = 'termusages_detail',
	options.option_key   = 'usage_count',
	options.option_value = NEW.termusage_foreign,
	options.option_meta  = 1
ON DUPLICATE KEY UPDATE
	options.option_meta = IF(options.option_meta IS NULL OR options.option_meta = '', 1, options.option_meta + 1);

UPDATE IGNORE
	options
SET
	options.option_meta = IF(options.option_meta IS NULL OR options.option_meta = '' OR options.option_meta < 1, 0, options.option_meta - 1)
WHERE
	options.user_id      IS NULL AND
	options.post_id      IS NULL AND
	options.option_cat   = 'termusages_detail' AND
	options.option_key   = 'usage_count' AND
	options.option_value = OLD.termusage_foreign;




END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `transactionitems`
--

CREATE TABLE `transactionitems` (
  `id` int(10) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `caller` varchar(100) NOT NULL,
  `unit_id` smallint(5) UNSIGNED NOT NULL,
  `type` enum('real','gift','prize','transfer') NOT NULL,
  `minus` double UNSIGNED DEFAULT NULL,
  `plus` double UNSIGNED DEFAULT NULL,
  `autoverify` enum('yes','no') NOT NULL DEFAULT 'no',
  `forcechange` enum('yes','no') NOT NULL DEFAULT 'no',
  `desc` text,
  `meta` text,
  `status` enum('enable','disable','deleted','expired','awaiting','filtered','blocked','spam') NOT NULL,
  `count` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `enddate` datetime DEFAULT NULL,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `transactions`
--

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `transactionitem_id` int(10) UNSIGNED NOT NULL,
  `exchangerate_id` int(10) UNSIGNED DEFAULT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `post_id` bigint(20) UNSIGNED DEFAULT NULL,
  `related_user_id` int(10) UNSIGNED DEFAULT NULL,
  `type` enum('real','gift','prize','transfer') NOT NULL,
  `unit_id` smallint(5) UNSIGNED NOT NULL,
  `plus` double DEFAULT NULL,
  `minus` double DEFAULT NULL,
  `budgetbefore` double DEFAULT NULL,
  `budget` double DEFAULT NULL,
  `status` enum('enable','disable','deleted','expired','awaiting','filtered','blocked','spam') NOT NULL,
  `meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `desc` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `finished` enum('yes','no') NOT NULL DEFAULT 'no',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Triggers `transactions`
--
DELIMITER $$
CREATE TRIGGER `transactions_change_transactionitems_count_on_insert` AFTER INSERT ON `transactions` FOR EACH ROW BEGIN
	UPDATE
		transactionitems
	SET
		transactionitems.count = IF(transactionitems.count IS NULL OR transactionitems.count = '', 1, transactionitems.count + 1)
	WHERE
		transactionitems.id = NEW.transactionitem_id
	LIMIT 1;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `units`
--

CREATE TABLE `units` (
  `id` smallint(5) UNSIGNED NOT NULL,
  `title` varchar(100) NOT NULL,
  `desc` text,
  `meta` text,
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userdashboards`
--

CREATE TABLE `userdashboards` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `poll_answered` int(10) UNSIGNED DEFAULT '0',
  `poll_skipped` int(10) UNSIGNED DEFAULT '0',
  `survey_answered` int(10) UNSIGNED DEFAULT '0',
  `survey_skipped` int(10) UNSIGNED DEFAULT '0',
  `my_poll` int(10) UNSIGNED DEFAULT '0',
  `my_survey` int(10) UNSIGNED DEFAULT '0',
  `my_poll_answered` int(10) UNSIGNED DEFAULT '0',
  `my_poll_skipped` int(10) UNSIGNED DEFAULT '0',
  `my_survey_answered` int(10) UNSIGNED DEFAULT '0',
  `my_survey_skipped` int(10) UNSIGNED DEFAULT '0',
  `user_referred` int(10) UNSIGNED DEFAULT '0',
  `user_verified` int(10) UNSIGNED DEFAULT '0',
  `comment_count` int(10) UNSIGNED DEFAULT '0',
  `draft_count` int(10) UNSIGNED DEFAULT '0',
  `publish_count` int(10) UNSIGNED DEFAULT '0',
  `awaiting_count` int(10) UNSIGNED DEFAULT '0',
  `my_fav` int(10) UNSIGNED DEFAULT '0',
  `my_like` int(10) UNSIGNED DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `userranks`
--

CREATE TABLE `userranks` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(10) UNSIGNED NOT NULL,
  `reported` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `usespamword` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `changeprofile` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `improveprofile` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `report` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `wrongreport` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `skip` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `resetpassword` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `verification` bit(1) NOT NULL DEFAULT b'0',
  `validation` bit(1) NOT NULL DEFAULT b'0',
  `vip` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `hated` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `other` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pollanswered` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `pollskipped` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `surveyanswered` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `surveyskipped` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `mypollanswered` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `mypollskipped` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `mysurveyanswered` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `mysurveyskipped` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `userreferred` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `userverified` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `commentcount` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `value` bigint(20) NOT NULL DEFAULT '0',
  `createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `datemodified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_mobile` varchar(15) NOT NULL,
  `user_email` varchar(100) DEFAULT NULL,
  `user_username` varchar(50) DEFAULT NULL,
  `user_pass` varchar(64) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `user_displayname` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `user_meta` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  `user_status` enum('active','awaiting','deactive','removed','filter','spam','block','delete') DEFAULT 'awaiting',
  `user_permission` varchar(1000) DEFAULT NULL,
  `user_createdate` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `user_parent` int(10) UNSIGNED DEFAULT NULL,
  `user_validstatus` enum('valid','invalid') NOT NULL DEFAULT 'invalid',
  `filter_id` bigint(20) UNSIGNED DEFAULT NULL,
  `user_port` enum('site','api','guest','android','telegram','instagram','google','linkedin','github','facebook','twitter','other','ios','wp','site_guest','api_guest','telegram_guest','android_guest','sms') DEFAULT NULL,
  `user_trust` enum('valid','invalid','unknown') DEFAULT NULL,
  `user_verify` enum('mobile','complete','unknown','uniqueid') DEFAULT NULL,
  `user_lang` varchar(4) DEFAULT NULL,
  `user_unit` smallint(5) DEFAULT NULL,
  `date_modified` timestamp NULL DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP,
  `user_language` char(2) DEFAULT NULL,
  `unit_id` smallint(5) UNSIGNED DEFAULT NULL,
  `user_ask` bigint(20) UNSIGNED DEFAULT NULL,
  `user_group` varchar(100) CHARACTER SET utf8mb4 DEFAULT NULL,
  `user_file_id` int(20) UNSIGNED DEFAULT NULL,
  `user_chat_id` int(20) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Triggers `users`
--
DELIMITER $$
CREATE TRIGGER `users_change_filters_count_on_update` AFTER UPDATE ON `users` FOR EACH ROW BEGIN
		UPDATE IGNORE filters SET filters.count = IF(filters.count IS NULL OR filters.count = '', 1, filters.count + 1) WHERE filters.id = NEW.filter_id LIMIT 1;
		UPDATE IGNORE filters SET filters.count = IF(filters.count IS NULL OR filters.count = '' OR filters.count < 1, 0, filters.count - 1) WHERE filters.id = OLD.filter_id LIMIT 1;
END
$$
DELIMITER ;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `answerdetails`
--
ALTER TABLE `answerdetails`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_id` (`post_id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `answer_id` (`answer_id`),
  ADD KEY `status` (`status`);

--
-- Indexes for table `answers`
--
ALTER TABLE `answers`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `answers_unique` (`post_id`,`user_id`) USING BTREE,
  ADD KEY `answers_user_id` (`user_id`);

--
-- Indexes for table `apilogs`
--
ALTER TABLE `apilogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `comments_posts_id` (`post_id`) USING BTREE,
  ADD KEY `comments_users_id` (`user_id`) USING BTREE,
  ADD KEY `comments_visitors_id` (`visitor_id`);

--
-- Indexes for table `exchangerates`
--
ALTER TABLE `exchangerates`
  ADD PRIMARY KEY (`id`),
  ADD KEY `exchangerates_units_id_from` (`from`) USING BTREE,
  ADD KEY `exchangerates_units_id_to` (`to`) USING BTREE;

--
-- Indexes for table `filters`
--
ALTER TABLE `filters`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logitems`
--
ALTER TABLE `logitems`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `logs`
--
ALTER TABLE `logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `logs_users_id` (`user_id`) USING BTREE,
  ADD KEY `logs_logitems_id` (`logitem_id`) USING BTREE;

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`id`),
  ADD KEY `notifications_users_idsender` (`user_idsender`) USING BTREE,
  ADD KEY `notifications_users_id` (`user_id`) USING BTREE,
  ADD KEY `notificationstatus_index` (`notification_status`) USING BTREE;

--
-- Indexes for table `options`
--
ALTER TABLE `options`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `cat+key+value` (`option_cat`,`option_key`,`option_value`) USING BTREE,
  ADD KEY `options_users_id` (`user_id`),
  ADD KEY `options_posts_id` (`post_id`),
  ADD KEY `options_parent_id` (`parent_id`);

--
-- Indexes for table `polldetails`
--
ALTER TABLE `polldetails`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_opt` (`post_id`,`user_id`,`opt`) USING BTREE,
  ADD KEY `polldetails_ibfk_2` (`user_id`);

--
-- Indexes for table `pollopts`
--
ALTER TABLE `pollopts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique` (`post_id`,`key`) USING BTREE;

--
-- Indexes for table `pollstats`
--
ALTER TABLE `pollstats`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_post` (`post_id`,`port`,`subport`,`type`) USING BTREE;

--
-- Indexes for table `polltrees`
--
ALTER TABLE `polltrees`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `polltrees_unique` (`post_id`,`parent`,`opt`) USING BTREE,
  ADD KEY `polltrees_parent` (`parent`);

--
-- Indexes for table `posts`
--
ALTER TABLE `posts`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url_unique` (`post_url`,`post_language`) USING BTREE,
  ADD KEY `posts_users_id` (`user_id`) USING BTREE,
  ADD KEY `posts_post_prizeunit` (`post_prizeunit`),
  ADD KEY `post_rank` (`post_rank`);

--
-- Indexes for table `ranks`
--
ALTER TABLE `ranks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_post_id` (`post_id`) USING BTREE;

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique` (`code`) USING BTREE,
  ADD KEY `sessions_user_id` (`user_id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `termurl_unique` (`term_url`,`term_language`) USING BTREE,
  ADD KEY `terms_users_id` (`user_id`);

--
-- Indexes for table `termusages`
--
ALTER TABLE `termusages`
  ADD UNIQUE KEY `term+type+object_unique` (`term_id`,`termusage_id`,`termusage_foreign`) USING BTREE;

--
-- Indexes for table `transactionitems`
--
ALTER TABLE `transactionitems`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_caller` (`caller`) USING BTREE,
  ADD KEY `transactionitems_units_id` (`unit_id`) USING BTREE;

--
-- Indexes for table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactions_ibfk_2` (`related_user_id`),
  ADD KEY `transactions_ibfk_3` (`parent_id`),
  ADD KEY `transactions_user_id` (`user_id`) USING BTREE,
  ADD KEY `transactions_transaction_id` (`transactionitem_id`) USING BTREE,
  ADD KEY `transactions_unit_id` (`unit_id`) USING BTREE,
  ADD KEY `transactions_exchangerate_id` (`exchangerate_id`);

--
-- Indexes for table `units`
--
ALTER TABLE `units`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_title` (`title`) USING BTREE;

--
-- Indexes for table `userdashboards`
--
ALTER TABLE `userdashboards`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_id` (`user_id`) USING BTREE;

--
-- Indexes for table `userranks`
--
ALTER TABLE `userranks`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_user_id` (`user_id`) USING BTREE;

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `mobile_unique` (`user_mobile`) USING BTREE,
  ADD UNIQUE KEY `username_unique` (`user_username`),
  ADD KEY `users_filters_id` (`filter_id`) USING BTREE,
  ADD KEY `users_unit_id` (`unit_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `answerdetails`
--
ALTER TABLE `answerdetails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1889438;
--
-- AUTO_INCREMENT for table `answers`
--
ALTER TABLE `answers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1748422;
--
-- AUTO_INCREMENT for table `apilogs`
--
ALTER TABLE `apilogs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43;
--
-- AUTO_INCREMENT for table `exchangerates`
--
ALTER TABLE `exchangerates`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `filters`
--
ALTER TABLE `filters`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1282;
--
-- AUTO_INCREMENT for table `logitems`
--
ALTER TABLE `logitems`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1082;
--
-- AUTO_INCREMENT for table `logs`
--
ALTER TABLE `logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3733;
--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `options`
--
ALTER TABLE `options`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8498788;
--
-- AUTO_INCREMENT for table `polldetails`
--
ALTER TABLE `polldetails`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=648659;
--
-- AUTO_INCREMENT for table `pollopts`
--
ALTER TABLE `pollopts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=134329;
--
-- AUTO_INCREMENT for table `pollstats`
--
ALTER TABLE `pollstats`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=24242;
--
-- AUTO_INCREMENT for table `polltrees`
--
ALTER TABLE `polltrees`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=107;
--
-- AUTO_INCREMENT for table `posts`
--
ALTER TABLE `posts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10052644;
--
-- AUTO_INCREMENT for table `ranks`
--
ALTER TABLE `ranks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58028;
--
-- AUTO_INCREMENT for table `sessions`
--
ALTER TABLE `sessions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2141;
--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=701442;
--
-- AUTO_INCREMENT for table `transactionitems`
--
ALTER TABLE `transactionitems`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3217;
--
-- AUTO_INCREMENT for table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=43339;
--
-- AUTO_INCREMENT for table `units`
--
ALTER TABLE `units`
  MODIFY `id` smallint(5) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `userdashboards`
--
ALTER TABLE `userdashboards`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=955152;
--
-- AUTO_INCREMENT for table `userranks`
--
ALTER TABLE `userranks`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10962307;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `answerdetails`
--
ALTER TABLE `answerdetails`
  ADD CONSTRAINT `answersdetail_answer_id` FOREIGN KEY (`answer_id`) REFERENCES `answers` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `answers`
--
ALTER TABLE `answers`
  ADD CONSTRAINT `answers_post_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `answers_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `comments_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `exchangerates`
--
ALTER TABLE `exchangerates`
  ADD CONSTRAINT `exchangerates_units_id_from` FOREIGN KEY (`from`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `exchangerates_units_id_to` FOREIGN KEY (`to`) REFERENCES `units` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `logs`
--
ALTER TABLE `logs`
  ADD CONSTRAINT `logs_logitems_id` FOREIGN KEY (`logitem_id`) REFERENCES `logitems` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `logs_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `notifications`
--
ALTER TABLE `notifications`
  ADD CONSTRAINT `notifications_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `options`
--
ALTER TABLE `options`
  ADD CONSTRAINT `options_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `options_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `polldetails`
--
ALTER TABLE `polldetails`
  ADD CONSTRAINT `polldetails_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `polldetails_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pollopts`
--
ALTER TABLE `pollopts`
  ADD CONSTRAINT `pollopt_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `pollstats`
--
ALTER TABLE `pollstats`
  ADD CONSTRAINT `pollstats_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `polltrees`
--
ALTER TABLE `polltrees`
  ADD CONSTRAINT `polltrees_parent` FOREIGN KEY (`parent`) REFERENCES `posts` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `polltrees_post_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `posts`
--
ALTER TABLE `posts`
  ADD CONSTRAINT `posts_post_prizeunit` FOREIGN KEY (`post_prizeunit`) REFERENCES `units` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `posts_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `ranks`
--
ALTER TABLE `ranks`
  ADD CONSTRAINT `ranks_posts_id` FOREIGN KEY (`post_id`) REFERENCES `posts` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `sessions`
--
ALTER TABLE `sessions`
  ADD CONSTRAINT `sessions_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `terms`
--
ALTER TABLE `terms`
  ADD CONSTRAINT `terms_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Constraints for table `termusages`
--
ALTER TABLE `termusages`
  ADD CONSTRAINT `termusages_terms_id` FOREIGN KEY (`term_id`) REFERENCES `terms` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `transactionitems`
--
ALTER TABLE `transactionitems`
  ADD CONSTRAINT `transactionitems_units_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `transactions`
--
ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_exchangerate_id` FOREIGN KEY (`exchangerate_id`) REFERENCES `exchangerates` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_transactionitem_id` FOREIGN KEY (`transactionitem_id`) REFERENCES `transactionitems` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_transactions_id_parent` FOREIGN KEY (`parent_id`) REFERENCES `transactions` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_units_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_user_id_related` FOREIGN KEY (`related_user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE,
  ADD CONSTRAINT `transactions_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `userdashboards`
--
ALTER TABLE `userdashboards`
  ADD CONSTRAINT `userdashboards_user_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON UPDATE CASCADE;

--
-- Constraints for table `userranks`
--
ALTER TABLE `userranks`
  ADD CONSTRAINT `userranks_users_id` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `users`
--
ALTER TABLE `users`
  ADD CONSTRAINT `users_filters_id` FOREIGN KEY (`filter_id`) REFERENCES `filters` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `users_unit_id` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON UPDATE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
