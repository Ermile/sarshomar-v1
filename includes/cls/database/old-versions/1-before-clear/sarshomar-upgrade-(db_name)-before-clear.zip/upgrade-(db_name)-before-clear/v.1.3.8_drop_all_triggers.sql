DROP TRIGGER IF EXISTS `set_post_ranks`;
DROP TRIGGER IF EXISTS `transactionitems_count`;
DROP TRIGGER IF EXISTS `update_filters_count`;