DROP TRIGGER IF EXISTS `terms_set_terms_url_caller_on_insert`;
