DROP TRIGGER IF EXISTS `terms_set_terms_url_on_insert`;
DROP TRIGGER IF EXISTS `terms_change_terms_url_on_update`;
